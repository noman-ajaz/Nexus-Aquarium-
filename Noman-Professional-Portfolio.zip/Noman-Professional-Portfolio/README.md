# Noman Ajaz Ul Haq — Professional Portfolio

**Theme:** Luxury Beige × Elegant Sage  
**Type:** Responsive, static developer portfolio (HTML, CSS, JavaScript)  
**Owner:** Noman Ajaz Ul Haq, Karachi, Pakistan

## Quick start (Windows 10 / VS Code)

1. Extract `Noman-Professional-Portfolio.zip`.
2. Open the `Noman-Professional-Portfolio` folder.
3. Double-click `index.html` to see the site in your browser. No XAMPP or database is needed for this portfolio.
4. For a better developer workflow, open the folder in VS Code and use the **Live Server** extension (optional).

## Included features

- Luxury beige/cream and elegant sage-green design.
- Owner-provided original portrait (`assets/img/noman-portrait.webp`; converted to web-friendly format without changing appearance).
- Responsive desktop, tablet, and mobile layouts.
- Sticky navigation, animated section reveals, and back-to-top control.
- Project filters (**All**, **Completed**, **In progress**).
- Pop-up details for all seven projects; completed/in-progress status reflects the owner's confirmation.
- Skills, about, and collaboration sections.
- Functional GitHub, LinkedIn, email, and WhatsApp contact links.
- Contact form that **opens an email app** with a prewritten message. It is NOT connected to a backend or email-delivery service.
- Downloadable résumé PDF prepared from known profile and project information. **Please review and update it before using for job applications**, particularly education and project statements.
- Original SVG *illustrative mockups* for project cards (not actual screenshots of deployed sites).

## Project status (owner-confirmed)

| Project | Status |
|---|---|
| Blessed Home | Completed |
| Nexus Aquarium | Completed |
| MasarratMakeup | In progress |
| MediCare | In progress |
| Luxe Beauty | In progress |
| Ember & Oak | In progress |
| NovaDesk | In progress |

## Important: Live demo / source links

Project-specific URLs were **not provided or verified**. To avoid wrong/broken links, project cards currently open an informative project detail pop-up. The **Visit My GitHub** button leads to the owner's GitHub profile, not to an unverified project repository.

To add verified project links after deployment:

1. In `index.html`, find the relevant project card (search its title).
2. Add a link for its actual deployed URL to the card, for example:
   `<a href="https://YOUR-VERIFIED-URL" target="_blank" rel="noopener noreferrer">Live Website ↗</a>`
3. If you also want a link in the project popup, edit the project entry in `assets/js/main.js` and the popup markup/JS as needed.

> Replace `YOUR-VERIFIED-URL` only with a real project address. There is deliberately no fabricated demo link.

## Update your personal details

Search and replace in `index.html` (and in `assets/js/main.js` for the mailto recipient):

- Name: `Noman Ajaz Ul Haq`
- Email: `nomanaijaz671@gmail.com`
- WhatsApp: `923161259299` (international numeric format)
- GitHub: `https://github.com/noman-ajaz`
- LinkedIn: `https://www.linkedin.com/in/noman-ajaz-a203492bb/`

**Privacy note:** Your email and WhatsApp number are visible in a public website, because you supplied them for contact. If you want privacy, remove WhatsApp from `index.html` before publishing.

## Replace your portrait

- Replace `assets/img/noman-portrait.webp` with a new image of the same name, or change the `<img class="hero-photo">` path in `index.html`.
- Portrait crop/position is controlled in `assets/css/style.css` via `.hero-photo { object-position: center 23%; }`.

## Update the résumé

The included résumé PDF is a **draft generated from the information available** (contact info, skills, project status, and previously shared education). If anything needs correcting, edit or replace `assets/docs/Noman_Ajaz_Ul_Haq_Resume.pdf`. Keep the filename to preserve the download buttons.

## Publish free on GitHub Pages

1. Sign in to the GitHub profile `noman-ajaz`.
2. Create a **public** repository, e.g. `noman-portfolio`.
3. Upload the **files inside** `Noman-Professional-Portfolio/` to the repository root, keeping `index.html` at the top level.
4. Open repository **Settings → Pages**.
5. Set **Build and deployment → Deploy from a branch**; choose `main` and `/ (root)`; click **Save**.
6. After GitHub publishes the site, copy the exact URL from the Pages settings page. Do not guess it in advance.

## Files

```
Noman-Professional-Portfolio/
├── index.html
├── README.md
└── assets/
    ├── css/style.css
    ├── js/main.js
    ├── docs/Noman_Ajaz_Ul_Haq_Resume.pdf
    └── img/
        ├── noman-portrait.webp
        ├── favicon.svg
        └── projects/
            ├── blessed-home.svg
            ├── nexus-aquarium.svg
            ├── masarrat-makeup.svg
            ├── medicare.svg
            ├── luxe-beauty.svg
            ├── ember-oak.svg
            └── novadesk.svg
```

Made as a fully editable starter portfolio using local assets, no JavaScript framework, no database, and no paid dependencies. The optional Google Fonts load from the web; fallback fonts are provided.
